import javax.swing.*;
import java.awt.*;


public class Test extends JFrame {
	public Test(){
		this.setTitle("Test");
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
	}



	public static void main(String[] args) {
		JFrame frame = new Test();
		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
	    frame.setSize(screenSize.width, screenSize.height);
		frame.setResizable(false);
		frame.setVisible(true);
	}

}
